# CT v3.0.0.1

- CT release: `3.0.0.1`
- Effective date: `2026-10-02`
- Game versions: every version ID published in Mojang's official version manifest, including releases, snapshots, and legacy entries
- Type: Independent Minecraft Java Edition launcher
- Release status: Released
- Distribution: Official CT website download page
- Game files bundled: no

## Release Contents

CT v3.0.0.1 makes Microsoft sign-in work without any setup. The launcher now ships two sign-in methods and defaults to the built-in one:

- **Microsoft account (built-in)** — the default. Clicking `Sign in with Microsoft` starts the sign-in immediately: CT shows a short code, opens `microsoft.com/link`, and the user signs in with the Microsoft account email and password. No Azure application client ID is required, and nothing has to be configured first.
- **Custom Azure client ID (classic)** — the method from v2.x. It uses the Azure public client ID stored in `microsoft.clientId` or supplied through `CT_MICROSOFT_CLIENT_ID`, and remains available for users who registered their own Azure application.

The method is chosen in the settings card and persisted as the new `microsoft.loginMode` key (`builtIn` by default, `custom` for the classic method). Both methods run the same OAuth 2.0 device code flow, then the Xbox Live, XSTS, and Minecraft services exchanges, and the same Minecraft Java Edition ownership check before launch. The offline profile is unchanged and still one click away.

All other launcher behavior is unchanged: every version in Mojang's official manifest, SHA-1 verified downloads, Fabric mod detection with automatic profile routing, desktop launch of installed Fabric, Forge, and NeoForge profiles, the v2.2.0.1 CT dark interface, and the CT mod loader.

## Requirements

- Java 21 or later to run CT.
- Network access to Mojang metadata, official game file, and runtime endpoints.
- A Microsoft account that owns Minecraft Java Edition for online-mode servers.

## Download

Download `CT-Client-3.0.0.1.zip` from the CT website's release page. Extract the archive, then run `launch-macos.command`, `launch-windows.bat`, or `launch-linux.sh` for the current platform.

## License

This release is governed by [LICENSE.md](LICENSE.md). It licenses only CT-owned materials and grants no rights to Minecraft, Mojang, Microsoft, Fabric, Sodium, or other third-party materials.
