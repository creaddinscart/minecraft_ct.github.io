#!/bin/sh
set -u
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ "$#" -eq 0 ]; then
    printf '%s\n' "Drop one or more ct-module-*.jar files onto this file to install them."
    printf 'Press Return to close. '
    read -r _ || true
    exit 0
fi
java -jar CT-Main-4.3.0.jar --install-modules "$@"
printf '\n%s\n' "Starting CT-Main..."
nohup java -jar CT-Main-4.3.0.jar >/dev/null 2>&1 &
exit 0
