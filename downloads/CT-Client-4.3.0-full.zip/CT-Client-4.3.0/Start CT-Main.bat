@echo off
cd /d "%~dp0"
java -jar CT-Main-4.3.0.jar
if errorlevel 1 pause
