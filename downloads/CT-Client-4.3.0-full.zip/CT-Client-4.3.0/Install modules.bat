@echo off
cd /d "%~dp0"
if "%~1"=="" (
    echo Drop one or more ct-module-*.jar files onto this file to install them.
    pause
    exit /b 0
)
java -jar CT-Main-4.3.0.jar --install-modules %*
if errorlevel 1 pause
start "" javaw -jar CT-Main-4.3.0.jar
