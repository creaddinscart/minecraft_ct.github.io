# CT v2.0.0.1 Proprietary License

Rights holder: `Creaddinscart Teams`  
Applicable release: CT `2.0.0.1`  
Effective date: `2026-10-01`  
Governing law and venue: The laws of the rights holder's local jurisdiction; the competent courts in that jurisdiction, subject to mandatory applicable law.

This document fixes the terms of the root `LICENSE.md` to CT `2.0.0.1`. The definitions, limited personal-use grant, restrictions, third-party materials provisions, disclaimer, limitation of liability, termination, and general terms in the root license are incorporated by reference and form part of this release-specific license.

This license applies only to CT-owned code, documentation, and assets that the rights holder owns or is authorized to license. It grants no rights in Minecraft, Mojang, Microsoft, game files, trademarks, online services, Fabric, Sodium, or other third-party materials. Third-party terms and non-waivable statutory rights take precedence.

Before publication, confirm the rights-holder identity and specific local jurisdiction and obtain legal review. Until confirmed, this document is only a project license draft and must not be treated as a final commercial distribution license.