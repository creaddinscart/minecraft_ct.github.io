# CT v2.0.0.1

- CT release: `2.0.0.1`
- Effective date: `2026-10-01`
- Game versions: every version ID published in Mojang's official version manifest, including releases, snapshots, and legacy entries
- Type: Independent Minecraft Java Edition launcher
- Release status: Released
- Distribution: Official CT website download page
- Game files bundled: no

## Release Contents

CT v2.0.0.1 recognizes Fabric mod JARs in the configured game's `mods/` folder. When exactly one installed Fabric Loader profile matches the selected Minecraft version, CT automatically starts that profile so Fabric can load its mods, including Sodium. If the matching profile is missing, CT explains that Fabric Loader must be installed into the same game directory. If several matching profiles are installed, select one explicitly.

CT does not bundle or install Fabric Loader, Fabric API, Sodium, or other third-party mods. Use the loader's own installer and verify that each mod supports the selected Minecraft and Fabric Loader versions. CT-native mods continue to use the separate `ct.mod.json` format.

The launcher continues to support all versions in Mojang's official manifest, Microsoft sign-in, offline profiles, and desktop launch of installed Fabric, Forge, and NeoForge profiles. The release ZIP contains the runnable GUI JAR, platform launch scripts, English instructions, these release records, and no project source code or Minecraft game files.

## Requirements

- Java 21 or later to run CT.
- Network access to Mojang metadata, official game file, and runtime endpoints.
- A Microsoft account that owns Minecraft Java Edition for online-mode servers.

## Download

Download `CT-Client-2.0.0.1.zip` from the CT website's release page. Extract the archive, then run `launch-macos.command`, `launch-windows.bat`, or `launch-linux.sh` for the current platform.

## License

This release is governed by [LICENSE.md](LICENSE.md). It licenses only CT-owned materials and grants no rights to Minecraft, Mojang, Microsoft, Fabric, Sodium, or other third-party materials.