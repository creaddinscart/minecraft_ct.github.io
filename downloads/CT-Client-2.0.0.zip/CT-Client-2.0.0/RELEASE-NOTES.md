# CT v2.0.0

- CT release: `2.0.0`
- Game versions: every version ID published in Mojang's official version manifest, including releases, snapshots, and legacy entries
- Type: Independent Minecraft Java Edition launcher
- Release status: Released
- Distribution: Official CT website download page
- Game files bundled: no

## Release Contents

CT v2.0.0 loads the official Mojang version manifest and lets users select any listed Minecraft version in the desktop launcher. It defaults to the latest release and supports modern arguments, legacy `minecraftArguments`, Maven-coordinate libraries, native classifiers, and legacy Java runtime metadata. The command-line launcher accepts an explicit official version ID and defaults to the latest release.

The website is the distribution portal for CT release ZIPs. Each desktop ZIP contains the runnable GUI JAR, platform launch scripts, English instructions, release notes, license, and client profile; it excludes project source code. Minecraft game files continue to be downloaded directly from official Mojang endpoints by the desktop client and are not hosted in the CT release ZIP.

Fabric, Forge, and NeoForge profiles remain selectable after installation with their own installers. CT delegates mod loading to those loaders and does not bundle their files.

## Requirements

- Java 21 or later to run CT.
- Network access to Mojang metadata, official game file, and runtime endpoints.
- A Microsoft account that owns Minecraft Java Edition for online-mode servers.

## Download

Download `CT-Client-2.0.0.zip` from the CT website's release page. Extract the archive, then run `launch-macos.command`, `launch-windows.bat`, or `launch-linux.sh` for the current platform.

## License

This release is governed by [LICENSE.md](LICENSE.md). It licenses only CT-owned materials and grants no rights to Minecraft, Mojang, Microsoft, or third-party loader projects.
