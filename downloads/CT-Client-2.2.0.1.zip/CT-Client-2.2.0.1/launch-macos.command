#!/bin/sh
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
JAVA=java
if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then
    JAVA="$JAVA_HOME/bin/java"
fi
if ! command -v "$JAVA" >/dev/null 2>&1; then
    printf '%s\n' 'Java 21 or later was not found. Install Java, then try again.'
    read -r -p 'Press Enter to close this window.' _
    exit 1
fi
exec "$JAVA" -jar "$SCRIPT_DIR/ct-client.jar"
