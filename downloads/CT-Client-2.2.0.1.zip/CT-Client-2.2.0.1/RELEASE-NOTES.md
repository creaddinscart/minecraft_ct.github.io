# CT v2.2.0.1

- CT release: `2.2.0.1`
- Effective date: `2026-10-02`
- Game versions: every version ID published in Mojang's official version manifest, including releases, snapshots, and legacy entries
- Type: Independent Minecraft Java Edition launcher
- Release status: Released
- Distribution: Official CT website download page
- Game files bundled: no

## Release Contents

CT v2.2.0.1 rebuilds the desktop interface around the CT brand. The window now uses a dark launcher theme with the CT palette, a branded header with the version badge, grouped settings cards, custom-drawn buttons, fields, checkboxes, version selector, memory steppers, progress bar, and a rounded console panel. The layout arranges profile, memory, window size, directories, account, and JVM settings in two columns so the launcher output stays readable at the default window size.

All launcher behavior is unchanged. CT detects Fabric mod JARs in the configured game's `mods/` folder and automatically starts the sole installed Fabric Loader profile matching the selected Minecraft version. If no profile matches, CT explains that Fabric Loader must be installed into the same game directory; if several profiles match, select one explicitly.

The launcher continues to support all versions in Mojang's official manifest, Microsoft sign-in, offline profiles, and desktop launch of installed Fabric, Forge, and NeoForge profiles. The release ZIP contains the runnable GUI JAR, platform launch scripts, English instructions, these release records, and no project source code or Minecraft game files.

## Requirements

- Java 21 or later to run CT.
- Network access to Mojang metadata, official game file, and runtime endpoints.
- A Microsoft account that owns Minecraft Java Edition for online-mode servers.

## Download

Download `CT-Client-2.2.0.1.zip` from the CT website's release page. Extract the archive, then run `launch-macos.command`, `launch-windows.bat`, or `launch-linux.sh` for the current platform.

## License

This release is governed by [LICENSE.md](LICENSE.md). It licenses only CT-owned materials and grants no rights to Minecraft, Mojang, Microsoft, Fabric, Sodium, or other third-party materials.
