@echo off
setlocal
where java >nul 2>nul
if errorlevel 1 (
  echo Java 21 or later was not found. Install Java, then try again.
  pause
  exit /b 1
)
java -jar "%~dp0ct-client.jar"
if errorlevel 1 pause
