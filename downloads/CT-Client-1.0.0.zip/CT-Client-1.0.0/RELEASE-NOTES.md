# CT v1.0.0

- CT release: `1.0.0`
- Target game: Minecraft Java Edition `26.3`
- Type: Independent client/launcher project; not a Fabric mod
- Release status: Released; installs and launches the target game
- Default icon: `src/main/resources/favicon.ico`

## Release Contents

This directory records the target game version, distribution boundaries, and license for CT `1.0.0`. The release provides a desktop launcher, a command line entry point, a verified installer for the target game, Microsoft sign-in, offline profiles, and game process launching. It does not include Minecraft game files, official assets, third-party mods, or automatic updates.

`client-profile.json` is the machine-readable profile for this release. Before publication, review it alongside the actual build artifacts, signed manifest, dependency license inventory, and checksums. Do not modify the records of a published release; issue a new CT version for any change.

## Target Runtime

Minecraft `26.3` declares `java-runtime-epsilon` at Java 25. CT installs that runtime from the official runtime manifest, so a matching Java installation is not required on the host. Building CT itself requires JDK 21 or later.

## Installing and Running the Game

The launcher obtains every game file through official Mojang metadata and verifies each file against its published SHA-1. Game files are never bundled with CT and are never fetched from CT-controlled servers.

```sh
./mvnw package
java -jar target/ct-client-1.0.0.jar
```

The desktop window installs on first launch, or on demand through Install/Verify. Online play needs a Microsoft account that owns Minecraft Java Edition. The offline profile is intended for development and single-player testing and cannot join online-mode servers.

## License

This release is governed by the [LICENSE.md](LICENSE.md) in this directory. It licenses only CT-owned materials and does not license intellectual property belonging to Minecraft, Mojang, Microsoft, or any other third party.
