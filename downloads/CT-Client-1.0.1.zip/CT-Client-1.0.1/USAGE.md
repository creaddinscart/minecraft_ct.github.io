# CT Client Desktop Quick Start

## Launch

1. Extract the ZIP to a regular folder. Do not launch the application from the archive preview.
2. Install Java 21 or later.
3. On macOS, double-click `launch-macos.command`. On Windows, double-click `launch-windows.bat`. On Linux, run `launch-linux.sh`.
4. Sign in with Microsoft on first launch, or choose an offline profile for local testing. Minecraft game files are downloaded by CT from official Mojang metadata and are not included in this ZIP.

## Fabric, Forge, and NeoForge

Install the desired loader with its own installer, targeting the same game directory selected in CT. Open CT, click **Refresh profiles**, select the installed profile, and launch. CT installs the profile's vanilla Minecraft parent version when needed. The loader and its dependencies must be installed or repaired with that loader's installer.

## Game Directory and Settings

The default game directory is `~/.ct-client/game`. Change it in the CT window if needed; loader profiles and the `mods/` directory must be inside the selected game directory. Other non-secret settings are stored in `~/.ct-client/settings.properties`.

## Troubleshooting

- `java` is not found: install Java 21 or later, then run the launch script again.
- A Fabric/Forge/NeoForge profile is missing: confirm that its installer used CT's current game directory, then click **Refresh profiles**.
- An offline profile cannot join online-mode servers. Sign in with a Microsoft account that owns Minecraft Java Edition.
- For launch errors, check the CT output window and `<game directory>/logs/ct-client-launch.log`.

## ZIP Contents

- `ct-client.jar`: executable GUI JAR with runtime dependencies.
- `launch-macos.command`, `launch-windows.bat`, `launch-linux.sh`: one-click launch scripts for each desktop platform.
- `USAGE.md`, `RELEASE-NOTES.md`, `client-profile.json`, `LICENSE.md`: usage instructions and release records.

This distribution contains no Java runtime, Minecraft game files, third-party loaders, mods, or project source code.
