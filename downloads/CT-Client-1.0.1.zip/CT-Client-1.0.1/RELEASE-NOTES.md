# CT v1.0.1

- CT release: `1.0.1`
- Target game: Minecraft Java Edition `26.3`
- Type: Independent client/launcher project with CT-native mods and installed external loader profile launching
- Release status: Released; installs and launches the target game and detects installed Fabric, Forge, and NeoForge profiles
- Default icon: `src/main/resources/favicon.ico`

## Release Contents

This release adds desktop launching for Fabric, Forge, and NeoForge profiles already installed in the configured game directory. CT reads the profile's parent Minecraft version, main class, launch arguments, and loader libraries, then hands off to that loader's runtime. Install and repair each external loader with its own installer. The CT-native mod format and API remain separate from those loader ecosystems.

The release provides the desktop launcher, command line entry point, verified official game installer, Microsoft sign-in, offline profiles, and game process launching. It does not include Minecraft game files, official assets, third-party mods, external loader files, or automatic updates.

`client-profile.json` is the machine-readable profile for this release. Before publication, review it alongside the actual build artifacts, signed manifest, dependency license inventory, and checksums. Do not modify the records of a published release; issue a new CT version for any change.

## Target Runtime

Minecraft `26.3` declares `java-runtime-epsilon` at Java 25. CT installs that runtime from the official runtime manifest, so a matching Java installation is not required on the host. Building CT itself requires JDK 21 or later.

## Installing and Running the Game

The launcher obtains game files through official Mojang metadata and verifies each file against its published SHA-1. Game files are never bundled with CT and are never fetched from CT-controlled servers.

```sh
./mvnw package
java -jar target/ct-client-1.0.1.jar
```

The package phase also creates `HTML/downloads/CT-Client-1.0.1.zip`, ready for the documentation site's downloads section. It contains the executable GUI JAR, one-click launch scripts for macOS/Windows/Linux, English usage instructions, this release's notes and profile, and its license. It does not contain source code.

Install a supported external loader into CT's configured game directory, refresh the profile list, and select it before launching. Online play needs a Microsoft account that owns Minecraft Java Edition. Offline profiles are intended for development and single-player testing and cannot join online-mode servers.

## License

This release is governed by the [LICENSE.md](LICENSE.md) in this directory. It licenses only CT-owned materials and does not license intellectual property belonging to Minecraft, Mojang, Microsoft, or any other third party.
