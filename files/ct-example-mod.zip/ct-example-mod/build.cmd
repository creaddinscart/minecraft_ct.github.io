@echo off
if not exist classes mkdir classes
javac -d classes src\example\ExampleMod.java
jar --create --file ct-example-mod-1.0.0.jar -C classes . -C . ct.mod.json
if not exist "%USERPROFILE%\.ct-client\game\mods" mkdir "%USERPROFILE%\.ct-client\game\mods"
copy /y ct-example-mod-1.0.0.jar "%USERPROFILE%\.ct-client\game\mods\"
echo Installed to %USERPROFILE%\.ct-client\game\mods\ct-example-mod-1.0.0.jar
