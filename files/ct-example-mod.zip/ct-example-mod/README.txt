CT Example Mod project

This is the finished project from the "How to create a CT mod" tutorial
on the CT Client website. Folder layout:

  ct.mod.json                 mod metadata read by CT Loader
  src/example/ExampleMod.java mod source code
  build.sh                    macOS/Linux: compile, package, install
  build.cmd                   Windows: compile, package, install

Quick start:
  macOS/Linux:  sh build.sh
  Windows:      double-click build.cmd  (or run it from cmd)

Requires JDK 21 or later. After installing, launch CT Client and watch
for "[example]" lines in the console.
