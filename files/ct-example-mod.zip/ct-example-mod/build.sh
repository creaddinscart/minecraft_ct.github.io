#!/bin/sh
set -e
mkdir -p classes
javac -d classes src/example/ExampleMod.java
jar --create --file ct-example-mod-1.0.0.jar -C classes . -C . ct.mod.json
mkdir -p ~/.ct-client/game/mods
cp ct-example-mod-1.0.0.jar ~/.ct-client/game/mods/
echo "Installed to ~/.ct-client/game/mods/ct-example-mod-1.0.0.jar"
